﻿


$(document).ready(function () {
  
    $(function () {
        $('.navbar-toggle').click(function () {
            $('.navbar-nav').toggleClass('slide-in');
            $('.side-body').toggleClass('body-slide-in');
            $('#search').removeClass('in').addClass('collapse').slideUp(200);

            /// uncomment code for absolute positioning tweek see top comment in css
            //$('.absolute-wrapper').toggleClass('slide-in');

        });


    });

    var owl = $("#owl-demo");

    owl.owlCarousel({

        autoPlay: 3000, //Set AutoPlay to 3 seconds
        items: 7, //10 items above 1000px browser width
        itemsDesktop: [1000, 5], //5 items between 1000px and 901px
        itemsDesktopSmall: [900, 3], // betweem 900px and 601px
        itemsTablet: [600, 2], //2 items between 600 and 0

    });

    // Custom Navigation Events
    $(".next").click(function () {
        owl.trigger('owl.next');
    })
    $(".prev").click(function () {
        owl.trigger('owl.prev');
    })

    $(".backtotop").click(function (event) {
      
        event.preventDefault();
        $('html, body').animate({ scrollTop: 0 }, 600);
        return false;
    })


    $("body").niceScroll({
        scrollspeed: 100,
        mousescrollstep: 38,
        cursorwidth: 5,
        cursorborder: 0,
        cursorcolor: '#333',
        autohidemode: true,
        zindex: 999999999,
        horizrailenabled: false,
        cursorborderradius: 0,
    });

    var offset = 200;
    var duration = 500;
    $(window).scroll(function () {
        if ($(this).scrollTop() > offset) {
            $('.navbar-fixed-top').removeClass('navbarextraPadding');
            $('.navbar-fixed-top').addClass('navbarnonextraPadding');
            $('.backtotop').fadeIn(400);
        } else {
            $('.navbar-fixed-top').addClass('navbarextraPadding');
            $('.navbar-fixed-top').removeClass('navbarnonextraPadding');
            $('.backtotop').fadeOut(400);


        }
    });
});