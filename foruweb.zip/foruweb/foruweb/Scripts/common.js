﻿
var appPath = window.location.protocol + "//" + window.location.host;

function GetFormattedUrl(url) {
    return appPath + "/" + url + "/";
}