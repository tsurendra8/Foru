﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace foruweb.Controllers
{
    public class DashboardController : Controller
    {
        //
        // GET: /Dashboard/

        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Dashboard()
        {
            return View();
        }

        public ActionResult DashboardView()
        {
            return PartialView();
        }

        public ActionResult NewReport()
        {
            return PartialView();
        }

        public ActionResult ReportList()
        {
            return PartialView();
        }

    }
}
